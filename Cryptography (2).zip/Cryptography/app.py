from flask import Flask, render_template, request
from encrypt import encrypt, decrypt
from database import save_payment, get_all_payments, init_db

app = Flask(__name__)
init_db()

@app.route('/')
def home():
    return render_template('payment.html')

@app.route('/process', methods=['POST'])
def process():
    name = request.form['name']
    card_number = request.form['card_number']
    expiry = request.form['expiry']
    cvv = request.form['cvv']

    encrypted_data = {
        "name": encrypt(name),
        "card_number": encrypt(card_number),
        "expiry": encrypt(expiry),
        "cvv": encrypt(cvv)
    }

    save_payment(
        encrypted_data["name"],
        encrypted_data["card_number"],
        encrypted_data["expiry"],
        encrypted_data["cvv"]
    )

    return render_template("success.html")

@app.route('/view')
def view_data():
    records = get_all_payments()
    decrypted_records = []
    for record in records:
        decrypted_records.append({
            'id': record[0],
            'name': decrypt(record[1]),
            'card_number': decrypt(record[2]),
            'expiry': decrypt(record[3]),
            'cvv': decrypt(record[4])
        })
    return render_template("view.html", records=decrypted_records)

if __name__ == '__main__':
    app.run(debug=True)
