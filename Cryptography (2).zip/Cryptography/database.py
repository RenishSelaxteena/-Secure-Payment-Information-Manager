import sqlite3

def init_db():
    conn = sqlite3.connect('payments.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            card_number TEXT,
            expiry TEXT,
            cvv TEXT
        )
    ''')
    conn.commit()
    conn.close()

# This is the function app.py needs to import
def save_payment(name, card_number, expiry, cvv):
    conn = sqlite3.connect('payments.db')
    c = conn.cursor()
    c.execute("INSERT INTO payments (name, card_number, expiry, cvv) VALUES (?, ?, ?, ?)",
              (name, card_number, expiry, cvv))
    conn.commit()
    conn.close()



def get_all_payments():
    conn = sqlite3.connect('payments.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM payments")
    rows = cursor.fetchall()
    conn.close()
    return rows
