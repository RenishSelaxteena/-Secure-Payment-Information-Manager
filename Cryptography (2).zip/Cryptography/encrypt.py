from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64

# AES key must be 16, 24, or 32 bytes
SECRET_KEY = b'ThisIsASecretKey'  # Example: 16 bytes

def pad(data):
    while len(data) % 16 != 0:
        data += ' '
    return data

def unpad(data):
    return data.rstrip()

def encrypt(raw_data):
    raw_data = pad(raw_data)
    iv = get_random_bytes(16)
    cipher = AES.new(SECRET_KEY, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(raw_data.encode('utf-8'))
    return base64.b64encode(iv + encrypted).decode('utf-8')

def decrypt(enc_data):
    enc_data = base64.b64decode(enc_data)
    iv = enc_data[:16]
    cipher = AES.new(SECRET_KEY, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(enc_data[16:]).decode('utf-8')
    return unpad(decrypted)
