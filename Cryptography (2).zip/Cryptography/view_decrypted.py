# view_decrypted.py
import sqlite3
from encrypt import decrypt  # Make sure encrypt.py is in the same folder

# Connect to the database
conn = sqlite3.connect('payments.db')
cursor = conn.cursor()

# Fetch all records
cursor.execute("SELECT id, name, card_number, expiry, cvv FROM payments")
records = cursor.fetchall()

print("🔓 Decrypted Payment Records:")
print("="*50)
for record in records:
    decrypted = {
        'id': record[0],
        'name': decrypt(record[1]),
        'card_number': decrypt(record[2]),
        'expiry': decrypt(record[3]),
        'cvv': decrypt(record[4])
    }

    print(f"ID         : {decrypted['id']}")
    print(f"Name       : {decrypted['name']}")
    print(f"Card Number: {decrypted['card_number']}")
    print(f"Expiry     : {decrypted['expiry']}")
    print(f"CVV        : {decrypted['cvv']}")
    print("-" * 50)

conn.close()
